# Large-scale composed CLI

This directory illustrates how a large-scale CLI app could be structured.
