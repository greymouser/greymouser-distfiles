package sixel

func max(a, b int) int { //nolint:predeclared
	if a > b {
		return a
	}
	return b
}
