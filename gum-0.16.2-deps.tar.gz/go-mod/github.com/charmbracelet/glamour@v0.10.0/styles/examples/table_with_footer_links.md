| Name | Role | Handle |
| ---- | ---- | ------ |
| Andrey | Engineering | [@andreynering](https://github.com/andreynering) |
| Ayman | Engineering | [@aymanbagabas](https://github.com/aymanbagabas) |
| Bash | Engineering | [@bashbunni](https://github.com/bashbunni) |
| Carlos | Engineering | [@caarlos0](https://github.com/caarlos0) |
| Christian | Product | [@meowgorithm](https://github.com/meowgorithm) |
| Rapha | Intern | [@raphamorim](https://github.com/raphamorim) |
