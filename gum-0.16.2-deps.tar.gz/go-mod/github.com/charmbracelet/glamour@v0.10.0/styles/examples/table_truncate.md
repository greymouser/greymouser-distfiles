|  Name   | Description | Type | Required | Default |
|---------|----------------------------------------|------|----------|---------|
| command | A command to be executed inside the container to assess its health. Each space delimited token of the command is a separate array element. Commands exiting 0 are considered to be successful probes, whilst all other exit codes are considered failures. | yes  | hello | yep |
