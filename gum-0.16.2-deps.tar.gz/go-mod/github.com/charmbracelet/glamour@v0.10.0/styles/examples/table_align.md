| Label | Value | URL |
| :----- | :---: | ------: |
| First | foo | charm.sh |
| Second | bar | https://charm.sh |
