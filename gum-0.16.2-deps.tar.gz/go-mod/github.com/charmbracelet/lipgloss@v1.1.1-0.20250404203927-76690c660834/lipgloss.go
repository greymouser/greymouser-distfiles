// Package lipgloss provides style definitions for nice terminal layouts. Built
// with TUIs in mind.
package lipgloss
